<?php

	require_once("../bd_api.php");
    require_once ("../../../privado/php/lib/sendmail_class.php");

	

	class bd_prereservas extends BD_API {

		public function analiza_method() {
			$func = $this->function;
			$this->$func(); // espera que la URL sea del estilo : ..../personal/bd_personal.php/login
		}


		private function findPrereservasFilter() {
				$id=( isset($_REQUEST['id'])?$_REQUEST['id']:NULL);
				$sql = "select * from preReservas where  " .
				    " id is not null " .

					($id != NULL ? " AND (id = :id)  " : "") .
					($_REQUEST['mes'] != NULL && $_REQUEST['anyo'] != NULL ? " AND ( (month(fechaEntrada) = :mes AND year(fechaEntrada) = :anyo) or (month(fechaSalida) = :mes AND year(fechaSalida) = :anyo))  " : "") 
				//	( ? " AND (year(fechaEntrada) = :anyo)  " : "")
					;

				$sql .= " ORDER BY fechaEntrada"; 

				$stmt = ($this->link)->prepare($sql);

				if (strpos($sql, ':id') !== false) $stmt->bindParam(':id',  $id);
				if (strpos($sql, ':mes') !== false) $stmt->bindValue(':mes',  $_REQUEST['mes']);
				if (strpos($sql, ':anyo') !== false) $stmt->bindValue(':anyo',  $_REQUEST['anyo']);
				try {

					if  ($stmt->execute()) {
						$result= $stmt->fetchAll(PDO::FETCH_ASSOC);
                        echo json_encode($result);
					}
				}
				catch ( PDOException $Exception)  {
					die( $Exception->getMessage( )  );
				}
		}
		
        private function deleteBD() {
	       $sql = "delete from preReservas where id = :id";
	       $stmt = ($this->link)->prepare($sql);
	       $stmt->bindValue(':id',  $_REQUEST['id']);
	       
	       try {
	            $stmt->execute() ;
	            echo '{ "result": "OK" }';
	       }   
            catch ( PDOException $Exception)  {
                die( $Exception->getMessage( )  );
            }
	    }
	    
	    private function devolverPrereserva() {
	       // inserto registro en gastosCaja con tipo devolucion
	        $sql = "insert into gastos set fecha=now(), descripcion=:descripcion, cantidad=:cantidad, factura='', tipoGasto='D' ";
	       $stmt = ($this->link)->prepare($sql);
	       $str = $_REQUEST['cliente'].'-'.$_REQUEST['telefono'].'-'.$_REQUEST['descServicio'].'-'.$_REQUEST['fechaEntrada'].'-'.$_REQUEST['fechaSalida'].'-'.$_REQUEST['observaciones'];
	       $stmt->bindValue(':descripcion',  $str);
	       $stmt->bindValue(':cantidad',  $_REQUEST['ingresado']);
	       $stmt->execute() ;
	        
	       $sql = "delete from preReservas where id = :id";
	       $stmt = ($this->link)->prepare($sql);
	       $stmt->bindValue(':id',  $_REQUEST['id']);
	       
	       try {
	            $stmt->execute() ;
	            echo '{ "result": "OK" }';
	            $url = "https://vidawm.com/privado/php/lib/sendmail.php?accion=send&destino=jvilata@edicom.es&destinoCopia=&asunto=Devolución camping ".$_REQUEST['cliente']."&texto=".$str;

	            $idserver=new SendMail();
	            $idserver->envia("send","jvilata@edicom.es","","Devolver reserva a ".$_REQUEST['cliente'],$str,"","");
	       }   
            catch ( PDOException $Exception)  {
                die( $Exception->getMessage( )  );
            }
	    }
	    
		private function guardarBD() {
		        $id = (isset($_REQUEST['id']) ? $_REQUEST['id'] : -1);
		        $sql="select id from preReservas where id=:id";
	            $stmt = ($this->link)->prepare($sql);
	            $stmt->bindParam(':id',  $id);
	            if  ($stmt->execute()) {
	                $result= $stmt->fetchAll(PDO::FETCH_ASSOC);
	                if (count($result)<=0)  {// no existe , lo creo
	                    $sql="insert into preReservas ";
	                    $where="";
	                } else { // si que existe, actualizo
	                    $sql="update preReservas ";
	                    $where=" where id=:id ";
	                }
	            }
	                
				$sql = $sql.
	                "set idServicio=:idServicio, descServicio=:descServicio, fechaEntrada=:fechaEntrada, fechaSalida=:fechaSalida, cliente=:cliente, idCliente=:idCliente,  ".
	                     "idEstancia=:idEstancia, observaciones=:observaciones, telefono=:telefono, ingresado=:ingresado ".
                         ",user='".(isset($_SESSION['login'])?$_SESSION['login']:'system')."',ts=now() ".
                    $where;            
				$stmt = ($this->link)->prepare($sql);

	            if (isset($_REQUEST['id'])) $stmt->bindValue(':id',  $id);
				$stmt->bindValue(':idServicio',  $_REQUEST['idServicio']);
				$stmt->bindValue(':descServicio',  $_REQUEST['descServicio']);
				$stmt->bindValue(':fechaEntrada',  $_REQUEST['fechaEntrada']);
				$stmt->bindValue(':fechaSalida',  $_REQUEST['fechaSalida']);
				$stmt->bindValue(':cliente',  $_REQUEST['cliente']);
				$stmt->bindValue(':idCliente',  $_REQUEST['idCliente']);
				$stmt->bindValue(':telefono',  $_REQUEST['telefono']);
				$stmt->bindValue(':ingresado',  $_REQUEST['ingresado']);
				$stmt->bindValue(':idEstancia',  $_REQUEST['idEstancia']);
				$stmt->bindValue(':observaciones',  $_REQUEST['observaciones']);

				try {
					$stmt->execute() ;
	                $lastId= $this->link->lastInsertId();
	                echo "{\"id\":".$lastId."}";
				}
				catch ( PDOException $Exception)  {
					die( $Exception->getMessage( )  );
				}		
		}


	}

	

	// Initiiate Library

	

	$api = new bd_prereservas();

	$api->analiza_method();

?>