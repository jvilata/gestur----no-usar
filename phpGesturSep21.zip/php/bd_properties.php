<?php
# archivo: bd_properties
		 const DB_SERVER = "localhost";
		 const DB_USER = "vidawmco_gestur";
		 const DB_PASSWORD = "\$\$Denia2020";
		 const DB = "vidawmco_gestur";
 ?>